(function (lib, img, cjs) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 145,
	height: 223,
	fps: 24,
	color: "#FFFFFF",
	manifest: []
};

// symbols:
(lib.disabledbutton = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(51,51,51,0.298)").ss(1,1,1).p("ArSxXIWlAAMAAAAivI2lAAg");
	this.shape.setTransform(72.3,111.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(102,102,102,0.2)").s().p("ArSRXMAAAgiuIWlAAMAAAAiug");
	this.shape_1.setTransform(72.3,111.2);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1,-1,146.7,224.4);


(lib.bookmarkIconRt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f(base1iconColor).s().p("Aitj8IFbAAIAAH1IititIiuCxg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f(base1iconColor).s().p("Aj8CuIAAlbIH1AAIitCtICxCug");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f(base1iconColor).s().p("AitD9IAAn1ICtCtICuixIAAH5g");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f(base1iconColor).s().p("Aj4CuICtitIixiuIH5AAIAAFbg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-25.3,35,50.7);

(lib.bookmarkIconRt1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f(base2iconColor).s().p("Aitj8IFbAAIAAH1IititIiuCxg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f(base2iconColor).s().p("Aj8CuIAAlbIH1AAIitCtICxCug");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f(base2iconColor).s().p("AitD9IAAn1ICtCtICuixIAAH5g");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f(base2iconColor).s().p("Aj4CuICtitIixiuIH5AAIAAFbg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-25.3,35,50.7);


(lib.arrowicon = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f(arrowColor).s().p("Ag6gtIB1AAIg7Bag");
	this.shape.setTransform(5.9,4.6);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,11.9,9.2);


(lib.arrowbase = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f(arrowBaseColor).s().p("AhtBjIAAjFIDbAAIAADFg");
	this.shape.setTransform(11,10);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,22.1,20);


(lib.listPanelMc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* btn.useHandCursor=false;*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.btn = new lib.disabledbutton();
	this.btn.setTransform(73,111.2,1,1,0,0,0,72.3,111.2);
	new cjs.ButtonHelper(this.btn, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,-1,146.7,224.4);


(lib.arrow = function() {
	this.initialize();

	// Layer 1
	this.arrow = new lib.arrowicon();
	this.arrow.setTransform(11,10,1,1,0,0,0,5.9,4.6);

	this.base = new lib.arrowbase();
	this.base.setTransform(11,10,1,1,0,0,0,11,10);

	this.addChild(this.base,this.arrow);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,22.1,20);


(lib.openList = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrowmc = new lib.arrow();
	this.arrowmc.setTransform(0,0,1,1,0,0,0,11,10);

	this.timeline.addTween(cjs.Tween.get(this.arrowmc).wait(1).to({rotation:180},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11,-10,22.1,20);


(lib.custombookmarkrunTimeActions = function() {
	this.initialize();

	// Layer 3
	this.icon_mc = new lib.bookmarkIconRt();
	this.icon_mc.setTransform(setIconXY[selectedIconNum][selectedPosition][0],setIconXY[selectedIconNum][selectedPosition][1],1.5,1.5);
	
	this.icon_mc1 = new lib.bookmarkIconRt1();
	this.icon_mc1.setTransform(setIconXY[selectedIconNum][selectedPosition][0],setIconXY[selectedIconNum][selectedPosition][1],1.5,1.5);

	// Layer 2
	this.openList = new lib.openList();
	this.openList.setTransform(setArrowXY[selectedIconNum][selectedPosition][0],setArrowXY[selectedIconNum][selectedPosition][1],1.5,1.5);

	// Layer 1
	this.listPanel = new lib.listPanelMc();

	this.addChild(this.listPanel,this.openList,this.icon_mc1,this.icon_mc);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0.2,-0.5,145.7,223.4);


// stage content:
(lib.runtime = function() {
	this.initialize();

	// Layer 1
	this.runTime_mc = new lib.custombookmarkrunTimeActions();
	this.runTime_mc.setTransform(65.8,118.9,1,1,0,0,0,66.5,118.9);

	this.addChild(this.runTime_mc);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(72,111,145.7,223.4);

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;