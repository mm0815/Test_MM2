var movieWidth;
var movieHeight;
var lcap;
window.quizscope = 0;
var width
var height
var m_movieProps
var filename

var jumpToLastSlide, markAllSlides,markOnlyNormalSlides,markOnlyQuestionSlides, useThemeColors, normalIconColor, bookmarkedIconColor, normalIconThemeColor, bookmarkedIconThemeColor, arrowBaseColor, arrowColor
var base1iconColor,base2iconColor, selectedIconNum, selectedPosition

var boomkarkedSlides,currentSlide;
var listPanelBaseDiv

var isDevice;
var parentDeviceMotion;
var parentOrientation;
var lastOrientation;

var isResponsiveProject = false;
var mainCPNamespace;
var evtHandle;
var bookmarkCanvas
var longestWidthScaled = 132;
var paddingScaled = 2;

var myWidgetiFrame,bookmarkInteraction

var setIconXY = [
	[
		[33, 45],
		[113, 45],
		[33, 178],
		[113, 178]
	],
	[
		[44, 32],
		[103, 32],
		[44, 190],
		[103, 190]
	],
	[
		[33, 47],
		[113, 47],
		[33, 178],
		[113, 178]
	],
	[
		[44, 32],
		[103, 32],
		[44, 190],
		[103, 190]
	]
]
var setArrowXY = [
	[
		[75, 22],
		[71, 22],
		[75, 155],
		[71, 155]
	],
	[
		[22.90, 73],
		[81.90, 73],
		[22.90, 150],
		[81.90, 150]
	],
	[
		[75, 70],
		[71, 70],
		[75, 201],
		[71, 201]
	],
	[
		[64.50, 73],
		[123.90, 73],
		[64.50, 150],
		[123.90, 150]
	]
]
var setListXY = [
	[
		[4.30, 91.45],
		[4.30, 91.45],
		[4.30, 6.50],
		[4.30, 6.50]
	],
	[
		[4.30, 91.45],
		[4.30, 91.45],
		[4.30, 6.50],
		[4.30, 6.50]
	],
	[
		[4.30, 91.45],
		[4.30, 91.45],
		[4.30, 6.50],
		[4.30, 6.50]
	],
	[
		[4.30, 91.45],
		[4.30, 91.45],
		[4.30, 6.50],
		[4.30, 6.50]
	]
]


isDevice = {
	Android: function() {
		return navigator.userAgent.match(/Android/i) ? true : false;
	},
	BlackBerry: function() {
		return navigator.userAgent.match(/BlackBerry/i) ? true : false;
	},
	IOS: function() {
		return navigator.userAgent.match(/iPhone|iPad|iPod/i) ? true : false;
	},
	Windows: function() {
		return navigator.userAgent.match(/IEMobile/i) ? true : false;
	},
	any: function() {
		return (isDevice.Android() || isDevice.BlackBerry() || isDevice.IOS() || isDevice.Windows());
	}
};

resourceUse = {
	onLoad: function() {

		if (!this.captivate) return;
		lcap = this.captivate;

		handle = this.captivate.CPMovieHandle;
		//if (handle.isWidgetVisible() == true) {

			var lInteractiveWidgetHandle = this.captivate.CPMovieHandle.getInteractiveWidgetHandle();
			if (lInteractiveWidgetHandle) {
				if (lInteractiveWidgetHandle.shouldDisable()) this.disable();
			}

			this.movieProps = this.captivate.CPMovieHandle.getMovieProps();
			if (!this.movieProps) return;
			m_movieProps = this.movieProps;
			this.varHandle = this.movieProps.variablesHandle;
			m_VariableHandle = this.varHandle;
			//this.eventDisp = this.movieProps.eventDispatcher;
			evtHandle = this.movieProps.eventDispatcher;
			mainCPNamespace = this.movieProps.getCpHandle();
			isResponsiveProject = mainCPNamespace.responsive;
			this.xmlStr = this.captivate.CPMovieHandle.widgetParams();
			var size = this.OpenAjax.getSize();
			width = size.width;
			height = size.height;
			this.externalImage = '';
			this.description = '';

			movieWidth = parseInt(size.width.split("px")[0]);
			movieHeight = parseInt(size.height.split("px")[0]);
			
			//Captivate Event listener
			evtHandle.addEventListener(mainCPNamespace.WINDOWRESIZECOMPLETEDEVENT,updateSizeNPositionOnResizeComplete, false );
			evtHandle.addEventListener(mainCPNamespace.ORIENTATIONCHANGECOMPLETEDEVENT,updateSizeNPositionOnResizeComplete, false );
			
			evtHandle.addEventListener(evtHandle.SLIDE_ENTER_EVENT, checkSlide, false);  

			this.updateData();
			this.doUpdate();

			//if (parent.cpInQuizScope == true) {
				//id = setInterval(checkval, 100)
				//window.quizscope = 1
			//} else {
			id = setInterval(checkval, 100)
			//}
			//console.log(parent.cpInQuizScope)
		//}
	},

	//Handle Click, if Clicked Outside Widget ( will be called from captivate internally)
	onClickExternal: function(e) {
		var lMsg = 'On Click Received in Widget';
		if (e) {
			lMsg += "x=" + e.pageX + "y=" + e.pageY;
		}
		if (!this.captivate) return;
		//Call set Failure
		var lInteractiveWidgetHandle = this.captivate.CPMovieHandle.getInteractiveWidgetHandle();
	},
	updateData: function() {
		var allWidgets = window.parent.document.getElementsByClassName("cp-widget");
		var myFrameName = window.name;
		myWidgetiFrame = window.parent.document.getElementById(window.name);
		bookmarkInteraction =  document.getElementById("bookmarkDiv");
		bookmarkCanvas = document.getElementById("bookmarkCanvas");
		listPanelBaseDiv = document.getElementById("listPanelBase");
		
		if (myWidgetiFrame) {
			myWidgetiFrame.style.height = movieHeight + "px";
			myWidgetiFrame.style.width = movieWidth + "px";
		}
		var id = 0;
		var result = jQuery.parseXML(this.xmlStr);
		var resultDoc = jQuery(result);
		var strProp = resultDoc.find('string').text();

		//BREAKING UP THE XML FROM CAPTIVATE
		//Game Variable
		
		var selectedIconNumVar = resultDoc.find('#selectedIconNum');
        if (selectedIconNumVar){
            if (selectedIconNumVar.find('number')){
                selectedIconNum = parseInt(selectedIconNumVar.find('number').text())-1;
            }
        }
		
		var selectedPositionVar = resultDoc.find('#selectedPosition');
        if (selectedPositionVar){
            if (selectedPositionVar.find('number')){
                selectedPosition = parseInt(selectedPositionVar.find('number').text())-1;
            }
        }
		
		var jumpToLastSlideVar = resultDoc.find('#jumpToLastSlide');
        if (jumpToLastSlideVar){
            if (jumpToLastSlideVar.find('string')){
                jumpToLastSlide = jumpToLastSlideVar.find('string').text();
            }
        }
		
		var markAllSlidesVar = resultDoc.find('#markAllSlides');
		if (markAllSlidesVar) {
			if (markAllSlidesVar.find('string')) {
				markAllSlides = markAllSlidesVar.find('string').text();
			}
		}
		
		
		var markOnlyNormalSlidesVar = resultDoc.find('#markOnlyNormalSlides');
		if (markOnlyNormalSlidesVar) {
			if (markOnlyNormalSlidesVar.find('string')) {
				markOnlyNormalSlides = markOnlyNormalSlidesVar.find('string').text();
			}
		}
		
		var markOnlyQuestionSlidesVar = resultDoc.find('#markOnlyQuestionSlides');
		if (markOnlyQuestionSlidesVar) {
			if (markOnlyQuestionSlidesVar.find('string')) {
				markOnlyQuestionSlides = markOnlyQuestionSlidesVar.find('string').text();
			}
		}
		
		var useThemeColorsVar = resultDoc.find('#useThemeColors');
		if (useThemeColorsVar) {
			if (useThemeColorsVar.find('string')) {
				useThemeColors = useThemeColorsVar.find('string').text();
			}
		}
		
		//Get Color
		var normalIconColorHex = resultDoc.find('#normalIconColorHex');
		if (normalIconColorHex) {
			if (normalIconColorHex.find('string')) {
				normalIconColor = '#' + normalIconColorHex.find('string').text();
			}
		}
		
		var bookmarkedIconColorHex = resultDoc.find('#bookmarkedIconColorHex');
		if (bookmarkedIconColorHex) {
			if (bookmarkedIconColorHex.find('string')) {
				bookmarkedIconColor = '#' + bookmarkedIconColorHex.find('string').text();
			}
		}
		
		
		var normalIconThemeColorHex = resultDoc.find('#normalIconThemeColorHex');
		if (normalIconThemeColorHex) {
			if (normalIconThemeColorHex.find('string')) {
				normalIconThemeColor = '#' + normalIconThemeColorHex.find('string').text();
			}
		}
		
		
		var bookmarkedIconThemeColorhex = resultDoc.find('#bookmarkedIconThemeColorHex');
		if (bookmarkedIconThemeColorhex) {
			if (bookmarkedIconThemeColorhex.find('string')) {
				bookmarkedIconThemeColor = '#' + bookmarkedIconThemeColorhex.find('string').text();
			}
		}
		
		var arrowBaseColorHex = resultDoc.find('#arrowBaseColorHex');
		if (arrowBaseColorHex) {
			if (arrowBaseColorHex.find('string')) {
				var arrowBaseColorN = '#' + arrowBaseColorHex.find('string').text();
			}
		}
		
		var arrowColorHex = resultDoc.find('#arrowColorHex');
		if (arrowColorHex) {
			if (arrowColorHex.find('string')) {
				var arrowColorN = '#' + arrowColorHex.find('string').text();
			}
		}
		
		var arrowBaseThemeColorHex = resultDoc.find('#arrowBaseThemeColorHex');
		if (arrowBaseThemeColorHex) {
			if (arrowBaseThemeColorHex.find('string')) {
				var arrowBaseThemeColorN = '#' + arrowBaseThemeColorHex.find('string').text();
			}
		}
		
		var arrowThemeColorHex = resultDoc.find('#arrowThemeColorHex');
		if (arrowThemeColorHex) {
			if (arrowThemeColorHex.find('string')) {
				var arrowThemeColorN = '#' + arrowThemeColorHex.find('string').text();
			}
		}
		
		
		if(useThemeColors == "true"){
			base1iconColor = normalIconThemeColor;
			base2iconColor = bookmarkedIconThemeColor;
			arrowBaseColor = arrowBaseThemeColorN
			arrowColor = arrowThemeColorN
		}else{
			base1iconColor = normalIconColor;
			base2iconColor = bookmarkedIconColor;
			arrowBaseColor = arrowBaseColorN
			arrowColor = arrowColorN
		}
		
	},
	doUpdate: function() {
		resizeInteraction(width, height);
	},

};
resource_use = function() {
	//Check if the browser is Safari on Mac only to toggle the YES NO Button Positions
	//SystemIsMac = ( navigator.platform.match(/(iPad|iPhone|Mac)/g) ? true : false );
	return resourceUse;
}

function updateSizeNPositionOnResizeComplete(){
	resizeInteraction(width,height);
}

var scaleW, scaleH;
function resizeInteraction(thewidth, theheight) {
	var scale = 0;
	thewidth = String(thewidth).replace("px","");
	theheight = String(theheight).replace("px","");
	//if(thewidth<320){
		//thewidth = 320
	//}
	//if(theheight<350){
		//theheight = 350
	//}
	
	/**********************/
	//Modification made for Presenter same logic holds good for Captivate
	//iframe width and Height
	scaleW = thewidth / (145);
	scaleH = theheight/ (223);
	
	myWidgetiFrame.style.width = parseInt(parseInt(145*scaleW))+"px"
	myWidgetiFrame.style.height = parseInt(parseInt(223*scaleH))+"px"
	
	bookmarkInteraction.style.width = parseInt(parseInt(145*scaleW))+"px"
	bookmarkInteraction.style.height = parseInt(parseInt(223*scaleH))+"px"
	
	bookmarkCanvas.style.width = parseInt(parseInt(145*scaleW))+"px"
	bookmarkCanvas.style.height = parseInt(parseInt(223*scaleH))+"px"
	
	listPanelBaseDiv.style.width = parseInt(parseInt(138*scaleW))+"px"
	listPanelBaseDiv.style.height = parseInt(parseInt(124*scaleH))+"px";
	
	longestWidthScaled = 132*scaleW;
	paddingScaled = 2*scaleW;
	
	if(boomkarkedSlides!=undefined){
		if(boomkarkedSlides.length>=1){
			updateList();
		}
	}
	
	repositionInteraction();
}

function repositionInteraction(){
	listPanelBaseDiv.style.left = (setListXY[selectedIconNum][selectedPosition][0])*scaleW+"px"
	listPanelBaseDiv.style.top = (setListXY[selectedIconNum][selectedPosition][1])*scaleH+"px"
}

function checkval() {
	clearInterval(id);
	createBookMark();
}

function checkForLocalStorage(){
	if(typeof(Storage) !== "undefined") {
		// Code for localStorage/sessionStorage.
		//localStorage.clear();
		getFileName();
		getFromLocalStorage();
	} else {
		//console.log("Sorry! No Web Storage support..");
	}
}

function createBookMark(){
	boomkarkedSlides = new Array();
	
	bookmarkCanvas.width = movieWidth;
	bookmarkCanvas.height = movieHeight;
	
	//Apply text and Color features // ONLY Instructions will be set from here
	bookmarkRoot = new lib.runtime();
	bookmarkRoot.scaleX = movieWidth / 145;
	bookmarkRoot.scaleY = movieHeight / 223;
	
	bookmarkStage = new createjs.Stage(bookmarkCanvas);
	bookmarkStage.addChild(bookmarkRoot);
	bookmarkStage.enableMouseOver();
	
	//Enabling Touch
	createjs.Touch.enable(bookmarkStage);

	createjs.Ticker.setFPS(lib.properties.fps);
	createjs.Ticker.addEventListener("tick", bookmarkStage);

	scalePercentagew = movieWidth / 145;
	scalePercentageh = movieHeight / 223;

	scaleDiffw = movieWidth - 145;
	scaleDiffh = movieHeight - 223;
	
	bookmarkRoot.runTime_mc.icon_mc.addEventListener("mouseover", handleMouseOver);
	bookmarkRoot.runTime_mc.icon_mc.addEventListener("mouseout", handleMouseOut);
	bookmarkRoot.runTime_mc.icon_mc.addEventListener("click", bookMarkSlide);
	
	bookmarkRoot.runTime_mc.icon_mc1.addEventListener("mouseover", handleMouseOver);
	bookmarkRoot.runTime_mc.icon_mc1.addEventListener("mouseout", handleMouseOut);
	bookmarkRoot.runTime_mc.icon_mc1.addEventListener("click", removeBookMarkSlide);
	
	bookmarkRoot.runTime_mc.openList.addEventListener("mouseover", handleMouseOver);
	bookmarkRoot.runTime_mc.openList.addEventListener("mouseout", handleMouseOut);
	bookmarkRoot.runTime_mc.openList.addEventListener("click", showList);
	
	bookmarkRoot.runTime_mc.icon_mc.gotoAndStop(selectedIconNum);
	bookmarkRoot.runTime_mc.icon_mc1.gotoAndStop(selectedIconNum);
	bookmarkRoot.runTime_mc.icon_mc1.visible = false;
	bookmarkRoot.runTime_mc.listPanel.visible = false;
	bookmarkRoot.runTime_mc.openList.visible = false;

	if (selectedPosition == 2 || selectedPosition == 3) {
		bookmarkRoot.runTime_mc.openList.gotoAndStop(1)
	} else {
		bookmarkRoot.runTime_mc.openList.gotoAndStop(0)
	}
	
	listPanelBaseDiv.style.left = setListXY[selectedIconNum][selectedPosition][0]+"px"
	listPanelBaseDiv.style.top = setListXY[selectedIconNum][selectedPosition][1]+"px"
	listPanelBaseDiv.style.visibility = "hidden"
	checkForLocalStorage();

	if (jumpToLastSlide == "true") {
		if (boomkarkedSlides.length) {
			m_VariableHandle.cpCmndGotoSlideAndResume = Number(boomkarkedSlides[boomkarkedSlides.length - 1].slideNum) - 1
		}
	}
	updateSizeNPositionOnResizeComplete();
	checkSlide();
}

var iconClicked = false;
function bookMarkSlide(){
	currentSlide = Number(m_VariableHandle.rdinfoCurrentSlide + 1);
	if(!iconClicked){
		bookmarkRoot.runTime_mc.icon_mc1.visible = true;
		bookmarkRoot.runTime_mc.icon_mc.visible = false;
		iconClicked = true;
		addToBookmarkedList(currentSlide);
	}else{
		bookmarkRoot.runTime_mc.icon_mc1.visible = true;
		bookmarkRoot.runTime_mc.icon_mc.visible = false;
		iconClicked = false;
		removeFromBookmarkedList(currentSlide);
	}
	
	if (boomkarkedSlides.length <= 0) {
		bookmarkRoot.runTime_mc.openList.visible = false;
		bookmarkRoot.runTime_mc.listPanel.visible = false;
		listPanelBaseDiv.style.visibility = "hidden"
	} else {
		bookmarkRoot.runTime_mc.openList.visible = true;
	}
	updateList();
	checkSlide();
}

function removeBookMarkSlide(){
	currentSlide = Number(m_VariableHandle.rdinfoCurrentSlide + 1);
	if(!iconClicked){
		bookmarkRoot.runTime_mc.icon_mc.visible = true;
		bookmarkRoot.runTime_mc.icon_mc1.visible = false;
		iconClicked = true;
		addToBookmarkedList(currentSlide);
	}else{
		bookmarkRoot.runTime_mc.icon_mc.visible = true;
		bookmarkRoot.runTime_mc.icon_mc1.visible = false;
		iconClicked = false;
		removeFromBookmarkedList(currentSlide);
	}
	if (boomkarkedSlides.length <= 0) {
		bookmarkRoot.runTime_mc.openList.visible = false;
		bookmarkRoot.runTime_mc.listPanel.visible = false;
		listPanelBaseDiv.style.visibility = "hidden"
	} else {
		bookmarkRoot.runTime_mc.openList.visible = true;
	}
	updateList();
}

function addToBookmarkedList(currSlide) {
	var bookmarkedObj;
	var slideLab;
	if (m_VariableHandle.cpInfoCurrentSlideLabel == "") {
		slideLab = "Slide " + currSlide;
	} else {
		slideLab = m_VariableHandle.cpInfoCurrentSlideLabel;
	}
	bookmarkedObj = {slideNum:currSlide, slideLabel:slideLab, slideType:m_VariableHandle.cpInfoCurrentSlideType};
	boomkarkedSlides.push(bookmarkedObj);
	boomkarkedSlides.sort(function(a,b) { return parseFloat(a.slideNum) - parseFloat(b.slideNum)})
	saveToLocalStorage();
}

function removeFromBookmarkedList(currSlide) {
	for (var i = 0; i < boomkarkedSlides.length; i++) {
		if (boomkarkedSlides[i].slideNum == currSlide) {
			boomkarkedSlides.splice(i, 1);
		}
	}
	boomkarkedSlides.sort(function(a,b) { return parseFloat(a.slideNum) - parseFloat(b.slideNum)})
	saveToLocalStorage();
}

function saveToLocalStorage(){
	//console.log(JSON.stringify(boomkarkedSlides))
	try{
		localStorage.setItem(filename, JSON.stringify(boomkarkedSlides));
	}catch(er){
	}
}

function getFromLocalStorage(){
	if(localStorage.length>=1){
		var localStorageKeys = Object.keys(localStorage);
		for (var i = 0; i < localStorage.length; i++) {
			if(localStorage.key(i) == filename){
				boomkarkedSlides = (JSON.parse(localStorage.getItem(localStorage.key(i))));
				updateList();
				break;
			}
		}	
	}
}

function getFileName(){
	var loc= window.location.pathname;
	filename= loc.substring(0, loc.indexOf('/w',1));
	filename = filename.replace(/\//g,"");
	
	//console.log(filename," getFileName filename")
}

function updateList(){
	listPanelBaseDiv.innerHTML = "";
	for (var i = 0; i < boomkarkedSlides.length; i++) {
		var listMc = createDiv(boomkarkedSlides[i].slideNum,boomkarkedSlides[i].slideLabel, boomkarkedSlides[i].slideType)
		listPanelBaseDiv.appendChild(listMc);
		$(listMc).mouseover(function(e) {
			e.target.style.cursor = "pointer";
		});
		$(listMc).click(function(e) {
			m_VariableHandle.cpCmndGotoSlideAndResume = (e.target.id)-1;
			//bookmarkRoot.runTime_mc.listPanel.visible = false;
			//listPanelBaseDiv.style.visibility = "hidden"
			//listOpened = false;
		});
	}
	resizeLables();
}

function resizeLables() {
	var longestWidth = longestWidthScaled;
	var setPadding = paddingScaled;
	var i;
	var j;
	if (boomkarkedSlides.length > 0) {
		for (i = 0; i < boomkarkedSlides.length; i++) {
			var curmcs = document.getElementById(boomkarkedSlides[i].slideNum);
			if (i >= 1) {
				var prevmcs = document.getElementById(boomkarkedSlides[i-1].slideNum);
				if (prevmcs.getElementsByTagName("div")[0].offsetWidth > longestWidth) {
					longestWidth = prevmcs.getElementsByTagName("div")[0].offsetWidth
				}else{
					if(curmcs.getElementsByTagName("div")[0].offsetWidth > longestWidth){
						longestWidth = curmcs.getElementsByTagName("div")[0].offsetWidth
					}
				}
			}else{
				if(curmcs.getElementsByTagName("div")[0].offsetWidth > longestWidth){
					longestWidth = curmcs.getElementsByTagName("div")[0].offsetWidth
				}
			}
		}
		for (j = 0; j < boomkarkedSlides.length; j++) {
			var modmcs = document.getElementById(boomkarkedSlides[j].slideNum);
			modmcs.style.width =  longestWidth+"px";
			modmcs.style.padding = setPadding+"px";
		}
	}
}

function createDiv(varInt, varLabel, varType){
	var newdiv = document.createElement('div');
	newdiv.id = varInt;
	newdiv.class = "listMcClass";
	newdiv.style.position = "relative"
	newdiv.style.width = "132px"
	newdiv.style.height = "20px"
	if(varType=="Normal Slide"){
		newdiv.style.backgroundColor = "#FFFFFF"
	}else{
		newdiv.style.backgroundColor = "#CCCB80"
	}
	newdiv.style.border = "1px Solid";
	newdiv.style.borderColor = "#999999";
	newdiv.style.fontFamily = "Tahoma"
	newdiv.style.fontSize = "13px"
	newdiv.style.padding = "2px"
	var contentdiv = document.createElement('div');
	contentdiv.id = varInt;
	contentdiv.class = "contentClass"
	contentdiv.innerHTML = contentdiv.innerHTML + varLabel;
	contentdiv.contentEditable = false;
	contentdiv.style["white-space"] = "nowrap";
	contentdiv.style.display = "inline-block"
	newdiv.appendChild(contentdiv);
	return newdiv;
}

function checkSlide(){
	currentSlide = Number(m_VariableHandle.rdinfoCurrentSlide + 1);
	
	//bookmarkRoot.runTime_mc.listPanel.visible = false;
	//listPanelBaseDiv.style.visibility = "hidden"
	//listOpened = false;
	
	//Check if slide has already been bookmarked
	var i;
	var iVal = -1;
	var currentSlideBookmarked = false;

	if (boomkarkedSlides.length <= 0) {
		bookmarkRoot.runTime_mc.openList.visible = false;
	} else {
		bookmarkRoot.runTime_mc.openList.visible = true;
		for (i = 0; i < boomkarkedSlides.length; i++) {
			if (currentSlide == boomkarkedSlides[i].slideNum) {
				currentSlideBookmarked = true;
				iVal = i;
				break;
			}
		}
	}
	
	clearDivsBg();
	if(iVal!=-1){
		var mcs = document.getElementById(boomkarkedSlides[i].slideNum)
		mcs.style.backgroundColor = "#CCCCCC"
	}
	
	if (currentSlideBookmarked==true) {
		bookmarkRoot.runTime_mc.icon_mc1.visible = true;
		bookmarkRoot.runTime_mc.icon_mc.visible = false;
		iconClicked = true;
	} else {
		bookmarkRoot.runTime_mc.icon_mc.visible = true;
		bookmarkRoot.runTime_mc.icon_mc1.visible = false;
		iconClicked = false;
	}
	
	if (markAllSlides=="true") {
		bookmarkRoot.runTime_mc.alpha = 1;
		bookmarkRoot.runTime_mc.icon_mc.mouseEnabled = true;
		bookmarkRoot.runTime_mc.icon_mc1.mouseEnabled = true;
		bookmarkRoot.runTime_mc.openList.mouseEnabled = true;
	}else if (markOnlyNormalSlides=="true") {
		if (m_VariableHandle.cpInfoCurrentSlideType == "Question Slide" || m_VariableHandle.cpInfoCurrentSlideType == "Random Question Slide") {
			bookmarkRoot.runTime_mc.alpha = 0.5;
			bookmarkRoot.runTime_mc.icon_mc.mouseEnabled = false;
			bookmarkRoot.runTime_mc.icon_mc1.mouseEnabled = false;
			bookmarkRoot.runTime_mc.openList.mouseEnabled = false;
			
			bookmarkRoot.runTime_mc.listPanel.visible = false;
			listPanelBaseDiv.style.visibility = "hidden"
			listOpened = false;
		}else{
			bookmarkRoot.runTime_mc.alpha = 1;
			bookmarkRoot.runTime_mc.icon_mc.mouseEnabled = true;
			bookmarkRoot.runTime_mc.icon_mc1.mouseEnabled = true;
			bookmarkRoot.runTime_mc.openList.mouseEnabled = true;
		}
	}else if (markOnlyQuestionSlides=="true") {
		if (m_VariableHandle.cpInfoCurrentSlideType == "Normal Slide") {
			bookmarkRoot.runTime_mc.alpha = 0.5;
			bookmarkRoot.runTime_mc.icon_mc.mouseEnabled = false;
			bookmarkRoot.runTime_mc.icon_mc1.mouseEnabled = false;
			bookmarkRoot.runTime_mc.openList.mouseEnabled = false;
			
			bookmarkRoot.runTime_mc.listPanel.visible = false;
			listPanelBaseDiv.style.visibility = "hidden"
			listOpened = false;
		}else{
			bookmarkRoot.runTime_mc.alpha = 1;
			bookmarkRoot.runTime_mc.icon_mc.mouseEnabled = true;
			bookmarkRoot.runTime_mc.icon_mc1.mouseEnabled = true;

			bookmarkRoot.runTime_mc.openList.mouseEnabled = true;
		}
	}
}


function clearDivsBg(){
	for (i = 0; i < boomkarkedSlides.length; i++) {
		var mcs = document.getElementById(boomkarkedSlides[i].slideNum)
		if(mcs!=null){
			mcs.style.backgroundColor = "#FFFFFF"
		}
	}
}

var listOpened = false;
function showList(){
	if(listOpened){
		bookmarkRoot.runTime_mc.listPanel.visible = false;
		listPanelBaseDiv.style.visibility = "hidden"
		listOpened = false;
	}else{
		bookmarkRoot.runTime_mc.listPanel.visible = true;
		listPanelBaseDiv.style.visibility = "visible"
		listOpened = true;
	}
}

$(window.parent.document).mousedown(function() {
	//bookmarkRoot.runTime_mc.listPanel.visible = false;
	//listPanelBaseDiv.style.visibility = "hidden"
	//listOpened = false;
});

$(window.parent.document).on("touchstart", function(ev) {
    //bookmarkRoot.runTime_mc.listPanel.visible = false;
	//listPanelBaseDiv.style.visibility = "hidden"
	//listOpened = false;
});

function handleMouseOver(evt) {
	bookmarkCanvas.style.cursor = "pointer";
}

function handleMouseOut(evt) {
	bookmarkCanvas.style.cursor = "default";
}

function updateVariable(){
	
}